function checkNumber() {
    const guessNumber = parseInt(document.getElementById('guess').value);

    if (tries > 0) {
        if (guessNumber == random) {

        document.getElementById('message').innerHTML = "Correct"
        tries = 0;
    }

    else if (guessNumber > random) {
        document.getElementById('message').innerHTML = "Lower";
    }

    else {
        document.getElementById('message').innerHTML = "Higher";
    }
    tries==

    document.getElementById('tries').innerHTML - "Tries left: " + tries;
}

if (tries === 0 && guessNumber != random) {
    document.getElementById('message').innerHTML = "Game Over";
}
    }