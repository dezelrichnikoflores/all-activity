function sum(num1, num2) {
    const sum = num1 + num2;
    console.log("The sum is " + sum);
}

function sub(num1, num2) {
    const sub = num1 - num2;
    console.log("The difference is " + sub);
}

function mul(num1, num2) {
    const mul = num1 * num2;
    console.log("The product is " + mul);
}

function div(num1, num2) {
    const div = num1 / num2;
    console.log("The quotient is " + div);
}